# Wallet Transaction Service — Full Stack

## Stack
- Frontend: HTML, CSS, JavaScript (served by Spring Boot)
- Backend: Java 21 + Spring Boot 3
- Security: Spring Security + JWT + BCrypt
- Database: PostgreSQL
- API docs: Swagger/OpenAPI
- Build: Maven
- Optional deployment: Docker Compose

## No Node.js required
The frontend is plain HTML/CSS/JavaScript and is served from Spring Boot `src/main/resources/static`.

## Local setup
1. Create PostgreSQL database `wallet_db`.
2. Check `src/main/resources/application.properties`.
3. Make sure Maven uses Java 21:
   `mvn -version`
4. Run:
   `mvn spring-boot:run`
5. Open:
   `http://localhost:8080/`
6. Swagger:
   `http://localhost:8080/swagger-ui.html`

## Default admin
Email: `admin@wallet.com`
Password: `Admin@123`

Change this password for any real/shared environment.

## Main API areas
- `/api/auth/**`
- `/api/wallet/**`
- `/api/issues/**`
- `/api/admin/**`

## Database
Hibernate `ddl-auto=update` creates/updates:
- users
- wallets
- transactions
- user_logs
- transaction_issues

The five tables and their important fields follow the provided Wallet Transaction Service specification.

## Important
This is a development starter implementation. Before production use, add stronger exception handling, audit logging on every required action, pagination, concurrency/locking strategy for wallet updates, comprehensive tests, password policy, and production secret management.
