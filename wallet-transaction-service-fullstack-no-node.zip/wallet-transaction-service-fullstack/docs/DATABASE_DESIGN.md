# Database Design

The project specification defines five tables:

## USERS
id, first_name, last_name, email, password, role, status, last_login_at, created_at, updated_at, password_reset_required

## WALLETS
id, wallet_number, user_id, balance, status, created_at, updated_at

## TRANSACTIONS
id, transaction_reference, wallet_id, transaction_type, amount, opening_balance, closing_balance, status, remarks, transaction_time, created_at

## USER_LOGS
id, user_id, activity_type, activity_description, entity_name, entity_id, old_value, new_value, status, created_at

## TRANSACTION_ISSUES
id, transaction_id, user_id, issue_title, issue_description, status, resolution_notes, created_at, updated_at

Business rules include one wallet per user, positive transaction amounts, no negative balance, successful credit/debit transaction records, transactional processing, authenticated wallet access, and user-owned transaction issue reporting.
