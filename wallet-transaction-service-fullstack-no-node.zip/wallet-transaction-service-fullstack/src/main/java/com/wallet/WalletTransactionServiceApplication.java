package com.wallet;

import com.wallet.entity.Role;
import com.wallet.entity.Status;
import com.wallet.entity.User;
import com.wallet.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class WalletTransactionServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(WalletTransactionServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner seedAdmin(UserRepository users, PasswordEncoder encoder) {
        return args -> {
            if (users.findByEmail("admin@wallet.com").isEmpty()) {
                User admin = new User();
                admin.setFirstName("System");
                admin.setLastName("Admin");
                admin.setEmail("admin@wallet.com");
                admin.setPassword(encoder.encode("Admin@123"));
                admin.setRole(Role.ADMIN);
                admin.setStatus(Status.ACTIVE);
                admin.setPasswordResetRequired(false);
                users.save(admin);
            }
        };
    }
}
