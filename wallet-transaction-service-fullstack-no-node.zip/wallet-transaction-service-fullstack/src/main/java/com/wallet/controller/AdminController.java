package com.wallet.controller;
import com.wallet.entity.*; import com.wallet.repository.*; import org.springframework.web.bind.annotation.*; import java.math.*; import java.util.*;
@RestController @RequestMapping("/api/admin")
public class AdminController{
 private final UserRepository users;private final WalletRepository wallets;private final TransactionRepository tx;private final UserLogRepository logs;
 public AdminController(UserRepository u,WalletRepository w,TransactionRepository t,UserLogRepository l){users=u;wallets=w;tx=t;logs=l;}
 @GetMapping("/wallets") public List<Wallet> wallets(){return wallets.findAll();}
 @GetMapping("/transactions") public List<WalletTransaction> transactions(){return tx.findAll();}
 @GetMapping("/logs") public List<UserLog> logs(){return logs.findAll();}
 @GetMapping("/dashboard") public Map<String,Object> dashboard(){
  BigDecimal credit=tx.findAll().stream().filter(t->t.getTransactionType()==TransactionType.CREDIT&&t.getStatus()==TransactionStatus.SUCCESS).map(WalletTransaction::getAmount).reduce(BigDecimal.ZERO,BigDecimal::add);
  BigDecimal debit=tx.findAll().stream().filter(t->t.getTransactionType()==TransactionType.DEBIT&&t.getStatus()==TransactionStatus.SUCCESS).map(WalletTransaction::getAmount).reduce(BigDecimal.ZERO,BigDecimal::add);
  return Map.of("totalUsers",users.count(),"totalWallets",wallets.count(),"totalTransactions",tx.count(),"totalCreditAmount",credit,"totalDebitAmount",debit);
 }
}
