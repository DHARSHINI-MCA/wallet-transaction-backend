package com.wallet.controller;
import com.wallet.entity.User; import com.wallet.repository.UserRepository; import com.wallet.security.JwtService; import jakarta.validation.constraints.*; import org.springframework.http.*; import org.springframework.security.authentication.*; import org.springframework.security.crypto.password.PasswordEncoder; import org.springframework.web.bind.annotation.*; import java.time.LocalDateTime; import java.util.Map;
@RestController @RequestMapping("/api/auth")
public class AuthController{
 record LoginRequest(@Email String email,@NotBlank String password){} record ResetRequest(@Email String email,@NotBlank String currentPassword,@NotBlank String newPassword){}
 private final AuthenticationManager auth; private final UserRepository users; private final PasswordEncoder enc; private final JwtService jwt;
 public AuthController(AuthenticationManager a,UserRepository u,PasswordEncoder e,JwtService j){auth=a;users=u;enc=e;jwt=j;}
 @PostMapping("/login") public ResponseEntity<?> login(@RequestBody LoginRequest r){
  try{auth.authenticate(new UsernamePasswordAuthenticationToken(r.email(),r.password())); User u=users.findByEmail(r.email()).orElseThrow();u.setLastLoginAt(LocalDateTime.now());users.save(u);return ResponseEntity.ok(Map.of("token",jwt.generate(u.getEmail(),u.getRole().name()),"role",u.getRole(),"passwordResetRequired",u.isPasswordResetRequired(),"name",u.getFirstName()));}
  catch(AuthenticationException e){return ResponseEntity.status(401).body(Map.of("message","Invalid email or password"));}
 }
 @PostMapping("/reset-password") public ResponseEntity<?> reset(@RequestBody ResetRequest r){
  User u=users.findByEmail(r.email()).orElseThrow(); if(!enc.matches(r.currentPassword(),u.getPassword()))return ResponseEntity.badRequest().body(Map.of("message","Current password is incorrect"));
  u.setPassword(enc.encode(r.newPassword()));u.setPasswordResetRequired(false);users.save(u);return ResponseEntity.ok(Map.of("message","Password reset successful"));
 }
}
