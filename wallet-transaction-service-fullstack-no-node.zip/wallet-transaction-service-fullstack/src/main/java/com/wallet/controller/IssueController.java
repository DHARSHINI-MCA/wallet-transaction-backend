package com.wallet.controller;
import com.wallet.entity.*; import com.wallet.repository.*; import org.springframework.security.core.Authentication; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/issues")
public class IssueController{
 record IssueRequest(String issueTitle,String issueDescription){}
 record UpdateRequest(IssueStatus status,String resolutionNotes){}
 private final UserRepository users;private final TransactionRepository tx;private final TransactionIssueRepository issues;
 public IssueController(UserRepository u,TransactionRepository t,TransactionIssueRepository i){users=u;tx=t;issues=i;}
 Long uid(Authentication a){return users.findByEmail(a.getName()).orElseThrow().getId();}
 @GetMapping public List<TransactionIssue> mine(Authentication a){return issues.findByUserIdOrderByCreatedAtDesc(uid(a));}
 @PostMapping("/{transactionId}") public TransactionIssue create(Authentication a,@PathVariable Long transactionId,@RequestBody IssueRequest r){
  User u=users.findById(uid(a)).orElseThrow(); WalletTransaction t=tx.findById(transactionId).orElseThrow();
  if(!t.getWallet().getUser().getId().equals(u.getId()))throw new RuntimeException("Transaction does not belong to user");
  TransactionIssue i=new TransactionIssue();i.setUser(u);i.setTransaction(t);i.setIssueTitle(r.issueTitle());i.setIssueDescription(r.issueDescription());return issues.save(i);
 }
 @GetMapping("/admin") public List<TransactionIssue> all(){return issues.findAll();}
 @PatchMapping("/admin/{id}") public TransactionIssue update(@PathVariable Long id,@RequestBody UpdateRequest r){TransactionIssue i=issues.findById(id).orElseThrow();i.setStatus(r.status());i.setResolutionNotes(r.resolutionNotes());return issues.save(i);}
}
