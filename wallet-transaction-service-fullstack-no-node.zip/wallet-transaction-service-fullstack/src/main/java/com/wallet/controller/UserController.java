package com.wallet.controller;
import com.wallet.entity.*; import com.wallet.repository.*; import jakarta.validation.constraints.*; import org.springframework.http.*; import org.springframework.security.crypto.password.PasswordEncoder; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/admin/users")
public class UserController{
 record CreateUser(@NotBlank String firstName,String lastName,@Email @NotBlank String email,@NotBlank String password){}
 private final UserRepository users; private final WalletRepository wallets; private final PasswordEncoder enc;
 public UserController(UserRepository u,WalletRepository w,PasswordEncoder e){users=u;wallets=w;enc=e;}
 @GetMapping public List<User> all(){return users.findAll();}
 @PostMapping public ResponseEntity<?> create(@RequestBody CreateUser r){
  if(users.findByEmail(r.email()).isPresent())return ResponseEntity.badRequest().body(Map.of("message","Email already exists"));
  User u=new User();u.setFirstName(r.firstName());u.setLastName(r.lastName());u.setEmail(r.email());u.setPassword(enc.encode(r.password()));u.setRole(Role.CUSTOMER);u.setStatus(Status.ACTIVE);users.save(u);
  Wallet w=new Wallet();w.setUser(u);w.setWalletNumber("WLT-"+UUID.randomUUID().toString().substring(0,8).toUpperCase());w.setBalance(java.math.BigDecimal.ZERO);w.setStatus(Status.ACTIVE);wallets.save(w);
  return ResponseEntity.ok(u);
 }
 @PatchMapping("/{id}/status") public User status(@PathVariable Long id,@RequestParam Status status){User u=users.findById(id).orElseThrow();u.setStatus(status);return users.save(u);}
}
