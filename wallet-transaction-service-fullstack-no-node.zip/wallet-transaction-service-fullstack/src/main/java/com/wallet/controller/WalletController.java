package com.wallet.controller;
import com.wallet.entity.*; import com.wallet.repository.*; import com.wallet.service.WalletService; import org.springframework.security.core.Authentication; import org.springframework.web.bind.annotation.*; import java.math.*; import java.util.*;
@RestController @RequestMapping("/api/wallet")
public class WalletController{
 record AmountRequest(BigDecimal amount,String remarks){}
 private final UserRepository users; private final WalletService service; private final TransactionIssueRepository issues; private final TransactionRepository tx;
 public WalletController(UserRepository u,WalletService s,TransactionIssueRepository i,TransactionRepository t){users=u;service=s;issues=i;tx=t;}
 Long userId(Authentication a){return users.findByEmail(a.getName()).orElseThrow().getId();}
 @GetMapping public Wallet balance(Authentication a){return service.balance(userId(a));}
 @PostMapping("/credit") public WalletTransaction credit(Authentication a,@RequestBody AmountRequest r){return service.move(userId(a),r.amount(),TransactionType.CREDIT,r.remarks());}
 @PostMapping("/debit") public WalletTransaction debit(Authentication a,@RequestBody AmountRequest r){return service.move(userId(a),r.amount(),TransactionType.DEBIT,r.remarks());}
 @GetMapping("/transactions") public List<WalletTransaction> history(Authentication a){return service.history(userId(a));}
}
