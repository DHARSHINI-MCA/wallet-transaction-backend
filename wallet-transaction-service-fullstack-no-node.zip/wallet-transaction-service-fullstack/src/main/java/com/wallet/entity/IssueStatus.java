package com.wallet.entity;
public enum IssueStatus { OPEN, IN_PROGRESS, RESOLVED }
