package com.wallet.entity;
public enum Role { CUSTOMER, ADMIN }
