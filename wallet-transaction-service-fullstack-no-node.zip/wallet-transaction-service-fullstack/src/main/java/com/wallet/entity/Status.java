package com.wallet.entity;
public enum Status { ACTIVE, INACTIVE }
