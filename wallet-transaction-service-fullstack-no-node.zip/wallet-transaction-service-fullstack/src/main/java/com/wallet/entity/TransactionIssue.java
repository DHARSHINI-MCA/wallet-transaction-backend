package com.wallet.entity;
import jakarta.persistence.*; import java.time.LocalDateTime;
@Entity @Table(name="transaction_issues")
public class TransactionIssue {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false) @JoinColumn(name="transaction_id") private WalletTransaction transaction;
 @ManyToOne(optional=false) @JoinColumn(name="user_id") private User user;
 @Column(name="issue_title",nullable=false,length=200) private String issueTitle;
 @Column(name="issue_description",nullable=false,columnDefinition="TEXT") private String issueDescription;
 @Enumerated(EnumType.STRING) @Column(nullable=false,length=20) private IssueStatus status=IssueStatus.OPEN;
 @Column(name="resolution_notes",columnDefinition="TEXT") private String resolutionNotes;
 @Column(name="created_at",nullable=false) private LocalDateTime createdAt;
 @Column(name="updated_at",nullable=false) private LocalDateTime updatedAt;
 @PrePersist void pre(){createdAt=LocalDateTime.now();updatedAt=createdAt;}
 @PreUpdate void upd(){updatedAt=LocalDateTime.now();}
 public Long getId(){return id;} public WalletTransaction getTransaction(){return transaction;} public void setTransaction(WalletTransaction v){transaction=v;}
 public User getUser(){return user;} public void setUser(User v){user=v;}
 public String getIssueTitle(){return issueTitle;} public void setIssueTitle(String v){issueTitle=v;}
 public String getIssueDescription(){return issueDescription;} public void setIssueDescription(String v){issueDescription=v;}
 public IssueStatus getStatus(){return status;} public void setStatus(IssueStatus v){status=v;}
 public String getResolutionNotes(){return resolutionNotes;} public void setResolutionNotes(String v){resolutionNotes=v;}
 public LocalDateTime getCreatedAt(){return createdAt;} public LocalDateTime getUpdatedAt(){return updatedAt;}
}
