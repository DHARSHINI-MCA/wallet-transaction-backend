package com.wallet.entity;
public enum TransactionType { CREDIT, DEBIT }
