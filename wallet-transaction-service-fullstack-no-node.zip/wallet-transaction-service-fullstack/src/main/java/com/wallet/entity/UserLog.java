package com.wallet.entity;
import jakarta.persistence.*; import java.time.LocalDateTime;
@Entity @Table(name="user_logs")
public class UserLog {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false) @JoinColumn(name="user_id") private User user;
 @Column(name="activity_type",nullable=false,length=50) private String activityType;
 @Column(name="activity_description") private String activityDescription;
 @Column(name="entity_name",length=100) private String entityName;
 @Column(name="entity_id") private Long entityId;
 @Column(name="old_value") private String oldValue;
 @Column(name="new_value") private String newValue;
 @Column(length=20) private String status;
 @Column(name="created_at",nullable=false) private LocalDateTime createdAt;
 @PrePersist void pre(){createdAt=LocalDateTime.now();}
 public Long getId(){return id;} public User getUser(){return user;} public void setUser(User v){user=v;}
 public String getActivityType(){return activityType;} public void setActivityType(String v){activityType=v;}
 public String getActivityDescription(){return activityDescription;} public void setActivityDescription(String v){activityDescription=v;}
 public String getEntityName(){return entityName;} public void setEntityName(String v){entityName=v;}
 public Long getEntityId(){return entityId;} public void setEntityId(Long v){entityId=v;}
 public String getOldValue(){return oldValue;} public void setOldValue(String v){oldValue=v;}
 public String getNewValue(){return newValue;} public void setNewValue(String v){newValue=v;}
 public String getStatus(){return status;} public void setStatus(String v){status=v;}
 public LocalDateTime getCreatedAt(){return createdAt;}
}
