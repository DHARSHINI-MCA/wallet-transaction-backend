package com.wallet.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name="wallets")
public class Wallet {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(name="wallet_number", nullable=false, unique=true, length=50) private String walletNumber;
    @OneToOne(optional=false) @JoinColumn(name="user_id", nullable=false, unique=true) private User user;
    @Column(nullable=false, precision=19, scale=2) private BigDecimal balance=BigDecimal.ZERO;
    @Enumerated(EnumType.STRING) @Column(nullable=false, length=20) private Status status=Status.ACTIVE;
    @Column(name="created_at", nullable=false) private LocalDateTime createdAt;
    @Column(name="updated_at", nullable=false) private LocalDateTime updatedAt;
    @PrePersist void prePersist(){createdAt=LocalDateTime.now();updatedAt=createdAt;}
    @PreUpdate void preUpdate(){updatedAt=LocalDateTime.now();}
    public Long getId(){return id;} public String getWalletNumber(){return walletNumber;} public void setWalletNumber(String v){walletNumber=v;}
    public User getUser(){return user;} public void setUser(User v){user=v;}
    public BigDecimal getBalance(){return balance;} public void setBalance(BigDecimal v){balance=v;}
    public Status getStatus(){return status;} public void setStatus(Status v){status=v;}
    public LocalDateTime getCreatedAt(){return createdAt;} public LocalDateTime getUpdatedAt(){return updatedAt;}
}
