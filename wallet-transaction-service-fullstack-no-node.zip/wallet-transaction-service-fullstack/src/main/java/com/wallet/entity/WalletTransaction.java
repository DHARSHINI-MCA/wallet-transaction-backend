package com.wallet.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name="transactions")
public class WalletTransaction {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(name="transaction_reference", nullable=false, unique=true, length=100) private String transactionReference;
    @ManyToOne(optional=false) @JoinColumn(name="wallet_id", nullable=false) private Wallet wallet;
    @Enumerated(EnumType.STRING) @Column(name="transaction_type", nullable=false, length=20) private TransactionType transactionType;
    @Column(nullable=false, precision=19, scale=2) private BigDecimal amount;
    @Column(name="opening_balance", nullable=false, precision=19, scale=2) private BigDecimal openingBalance;
    @Column(name="closing_balance", nullable=false, precision=19, scale=2) private BigDecimal closingBalance;
    @Enumerated(EnumType.STRING) @Column(nullable=false, length=20) private TransactionStatus status;
    @Column(length=500) private String remarks;
    @Column(name="transaction_time", nullable=false) private LocalDateTime transactionTime;
    @Column(name="created_at", nullable=false) private LocalDateTime createdAt;
    @PrePersist void prePersist(){createdAt=LocalDateTime.now();if(transactionTime==null)transactionTime=createdAt;}
    public Long getId(){return id;} public String getTransactionReference(){return transactionReference;} public void setTransactionReference(String v){transactionReference=v;}
    public Wallet getWallet(){return wallet;} public void setWallet(Wallet v){wallet=v;}
    public TransactionType getTransactionType(){return transactionType;} public void setTransactionType(TransactionType v){transactionType=v;}
    public BigDecimal getAmount(){return amount;} public void setAmount(BigDecimal v){amount=v;}
    public BigDecimal getOpeningBalance(){return openingBalance;} public void setOpeningBalance(BigDecimal v){openingBalance=v;}
    public BigDecimal getClosingBalance(){return closingBalance;} public void setClosingBalance(BigDecimal v){closingBalance=v;}
    public TransactionStatus getStatus(){return status;} public void setStatus(TransactionStatus v){status=v;}
    public String getRemarks(){return remarks;} public void setRemarks(String v){remarks=v;}
    public LocalDateTime getTransactionTime(){return transactionTime;} public LocalDateTime getCreatedAt(){return createdAt;}
}
