package com.wallet.repository;
import com.wallet.entity.TransactionIssue; import java.util.List; import org.springframework.data.jpa.repository.JpaRepository;
public interface TransactionIssueRepository extends JpaRepository<TransactionIssue,Long>{ List<TransactionIssue> findByUserIdOrderByCreatedAtDesc(Long userId); }
