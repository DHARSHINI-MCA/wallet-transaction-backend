package com.wallet.repository;
import com.wallet.entity.WalletTransaction; import java.util.List; import org.springframework.data.jpa.repository.JpaRepository;
public interface TransactionRepository extends JpaRepository<WalletTransaction,Long>{ List<WalletTransaction> findByWalletUserIdOrderByTransactionTimeDesc(Long userId); }
