package com.wallet.repository;
import com.wallet.entity.UserLog; import org.springframework.data.jpa.repository.JpaRepository;
public interface UserLogRepository extends JpaRepository<UserLog,Long>{}
