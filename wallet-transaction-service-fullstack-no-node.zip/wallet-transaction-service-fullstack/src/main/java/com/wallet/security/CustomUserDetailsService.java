package com.wallet.security;
import com.wallet.entity.User; import com.wallet.repository.UserRepository; import org.springframework.security.core.authority.SimpleGrantedAuthority; import org.springframework.security.core.userdetails.*; import org.springframework.stereotype.Service;
@Service public class CustomUserDetailsService implements UserDetailsService{
 private final UserRepository repo; public CustomUserDetailsService(UserRepository repo){this.repo=repo;}
 public UserDetails loadUserByUsername(String email)throws UsernameNotFoundException{
  User u=repo.findByEmail(email).orElseThrow(()->new UsernameNotFoundException("User not found"));
  return new org.springframework.security.core.userdetails.User(u.getEmail(),u.getPassword(),u.getStatus().name().equals("ACTIVE"),true,true,true,
   java.util.List.of(new SimpleGrantedAuthority("ROLE_"+u.getRole().name())));
 }
}
