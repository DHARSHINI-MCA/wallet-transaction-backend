package com.wallet.security;
import jakarta.servlet.*; import jakarta.servlet.http.*; import org.springframework.security.authentication.UsernamePasswordAuthenticationToken; import org.springframework.security.core.context.SecurityContextHolder; import org.springframework.security.core.userdetails.UserDetails; import org.springframework.security.web.authentication.WebAuthenticationDetailsSource; import org.springframework.stereotype.Component; import java.io.IOException;
@Component public class JwtAuthFilter extends OncePerRequestFilter{
 private final JwtService jwt; private final CustomUserDetailsService users;
 public JwtAuthFilter(JwtService jwt,CustomUserDetailsService users){this.jwt=jwt;this.users=users;}
 protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException{
  String h=req.getHeader("Authorization");
  if(h!=null&&h.startsWith("Bearer ")){String token=h.substring(7);if(jwt.valid(token)){try{String email=jwt.username(token);UserDetails ud=users.loadUserByUsername(email);var a=new UsernamePasswordAuthenticationToken(ud,null,ud.getAuthorities());a.setDetails(new WebAuthenticationDetailsSource().buildDetails(req));SecurityContextHolder.getContext().setAuthentication(a);}catch(Exception ignored){}}}
  chain.doFilter(req,res);
 }
}
