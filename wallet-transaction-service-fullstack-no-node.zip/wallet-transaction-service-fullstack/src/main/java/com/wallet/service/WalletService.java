package com.wallet.service;
import com.wallet.entity.*; import com.wallet.repository.*; import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional; import java.math.*; import java.util.*;
@Service public class WalletService{
 private final WalletRepository wallets; private final TransactionRepository tx;
 public WalletService(WalletRepository w,TransactionRepository t){wallets=w;tx=t;}
 Wallet wallet(Long userId){return wallets.findByUserId(userId).orElseThrow(()->new RuntimeException("Wallet not found"));}
 public Wallet balance(Long userId){return wallet(userId);}
 @Transactional public WalletTransaction move(Long userId,BigDecimal amount,TransactionType type,String remarks){
  if(amount==null||amount.signum()<=0)throw new IllegalArgumentException("Amount must be greater than zero");
  Wallet w=wallet(userId); if(w.getStatus()!=Status.ACTIVE)throw new IllegalStateException("Wallet is inactive");
  BigDecimal opening=w.getBalance(); BigDecimal closing=type==TransactionType.CREDIT?opening.add(amount):opening.subtract(amount);
  if(closing.signum()<0)throw new IllegalArgumentException("Insufficient balance");
  w.setBalance(closing);wallets.save(w);
  WalletTransaction t=new WalletTransaction();t.setWallet(w);t.setTransactionReference("TXN-"+UUID.randomUUID().toString().replace("-","").substring(0,16).toUpperCase());t.setTransactionType(type);t.setAmount(amount);t.setOpeningBalance(opening);t.setClosingBalance(closing);t.setStatus(TransactionStatus.SUCCESS);t.setRemarks(remarks);return tx.save(t);
 }
 public List<WalletTransaction> history(Long userId){return tx.findByWalletUserIdOrderByTransactionTimeDesc(userId);}
}
