# Wallet Transaction Service

A beginner-friendly enterprise-style backend based on the September 2026 project specification. It implements registration, JWT login, automatic wallet creation, balance inquiry, credit, debit, transaction history, issue reporting/status tracking, admin APIs, audit logging, PostgreSQL and Docker.

## Stack
- Java 21
- Spring Boot 3.5.x
- Maven
- Spring Web / Spring Security / Spring Data JPA / Validation
- PostgreSQL
- JWT (JJWT) + BCrypt
- Swagger/OpenAPI
- JUnit 5 / Mockito-ready test setup
- Docker Compose

## Database tables
The project follows the supplied specification: `users`, `wallets`, `transactions`, `user_logs`, and `transaction_issues`.

## Run locally
1. Start PostgreSQL and create database `wallet_db`, or use Docker Compose.
2. Check `src/main/resources/application.properties`.
3. Run:
   `mvn spring-boot:run`
4. Open Swagger:
   `http://localhost:8080/swagger-ui.html`

## Run everything with Docker
`docker compose up --build`

## Default admin
- Email: `admin@wallet.com`
- Password: `Admin@123`

Change this password/seed logic before any real deployment.

## Main API flow
1. POST `/api/auth/register` -> creates customer + wallet.
2. POST `/api/auth/login` -> returns JWT.
3. Add `Authorization: Bearer <token>` in Postman/Swagger.
4. GET `/api/wallets/me` -> balance.
5. POST `/api/transactions/credit` -> add money.
6. POST `/api/transactions/debit` -> subtract money only when balance is sufficient.
7. GET `/api/transactions/history` -> transaction history.
8. POST `/api/issues` -> report an issue for the user's own transaction.
9. Admin endpoints are under `/api/admin/**`.

## Important transaction behavior
Credit/debit uses `@Transactional`: wallet balance update and transaction record are committed together; an exception rolls the database transaction back.

## Notes for learning
This is a complete starter implementation, not a production-certified banking system. Before presenting it as production-ready, add stronger concurrency handling/locking, pagination, refresh tokens, secrets management, migrations (Flyway/Liquibase), comprehensive tests, error/status response DTOs, and a proper admin audit flow.
