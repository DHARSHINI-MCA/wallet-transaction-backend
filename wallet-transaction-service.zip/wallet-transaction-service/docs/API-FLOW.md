# Demo flow

1. Register customer -> user + wallet are created.
2. Login -> JWT returned.
3. Get wallet -> starting balance 0.00.
4. Credit 1000 -> balance 1000.00 + SUCCESS transaction.
5. Debit 250 -> balance 750.00 + SUCCESS transaction.
6. Try debit 1000 -> rejected; balance stays 750.00.
7. View history.
8. Report issue for own transaction.
9. Login as admin -> use `/api/admin/dashboard`, users, wallets, transactions, issues and logs.

All protected endpoints require `Authorization: Bearer <JWT>`.
