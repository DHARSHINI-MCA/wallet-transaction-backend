package com.wallet.service.controller;
import com.wallet.service.entity.User; import com.wallet.service.service.CurrentUserService; import org.springframework.security.core.Authentication; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/users") public class UserController { private final CurrentUserService current; public UserController(CurrentUserService c){current=c;} @GetMapping("/me") public User me(Authentication a){return current.get(a);} }
