package com.wallet.service.controller;
import com.wallet.service.entity.Wallet; import com.wallet.service.service.*; import org.springframework.security.core.Authentication; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/wallets") public class WalletController { private final WalletService wallets; private final CurrentUserService current; public WalletController(WalletService w,CurrentUserService c){wallets=w;current=c;} @GetMapping("/me") public Wallet me(Authentication a){return wallets.myWallet(current.get(a).getId());} }
