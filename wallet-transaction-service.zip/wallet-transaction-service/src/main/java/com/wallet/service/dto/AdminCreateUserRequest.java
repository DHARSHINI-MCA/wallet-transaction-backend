package com.wallet.service.dto;
import jakarta.validation.constraints.*;
import com.wallet.service.entity.Role;
public record AdminCreateUserRequest(@NotBlank String firstName,String lastName,@NotBlank @Email String email,@NotBlank @Size(min=8) String temporaryPassword,@NotNull Role role) {}
