package com.wallet.service.dto; public record AuthResponse(String token,String tokenType,Long userId,String email,String role,boolean passwordResetRequired) {}
