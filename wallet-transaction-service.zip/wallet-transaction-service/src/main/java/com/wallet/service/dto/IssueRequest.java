package com.wallet.service.dto; import jakarta.validation.constraints.*; public record IssueRequest(@NotNull Long transactionId,@NotBlank String issueTitle,@NotBlank String issueDescription) {}
