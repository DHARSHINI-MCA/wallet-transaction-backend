package com.wallet.service.dto; import jakarta.validation.constraints.*; public record PasswordResetRequest(@NotBlank String currentPassword,@NotBlank @Size(min=8) String newPassword) {}
