package com.wallet.service.entity;

public enum IssueStatus { OPEN, IN_PROGRESS, RESOLVED }
