package com.wallet.service.entity;

public enum Role { CUSTOMER, ADMIN }
