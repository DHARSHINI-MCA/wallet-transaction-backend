package com.wallet.service.entity;

import jakarta.persistence.*; import java.time.LocalDateTime;

@Entity @Table(name="transaction_issues")
public class TransactionIssue {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="transaction_id",nullable=false) private Transaction transaction;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="user_id",nullable=false) private User user;
 @Column(name="issue_title",nullable=false,length=200) private String issueTitle; @Column(name="issue_description",nullable=false) private String issueDescription;
 @Enumerated(EnumType.STRING) @Column(nullable=false,length=20) private IssueStatus status=IssueStatus.OPEN; @Column(name="resolution_notes") private String resolutionNotes;
 @Column(name="created_at",nullable=false) private LocalDateTime createdAt; @Column(name="updated_at",nullable=false) private LocalDateTime updatedAt;
 @PrePersist void pre(){var n=LocalDateTime.now();createdAt=n;updatedAt=n;} @PreUpdate void upd(){updatedAt=LocalDateTime.now();}
 public Long getId(){return id;} public Transaction getTransaction(){return transaction;} public void setTransaction(Transaction v){transaction=v;} public User getUser(){return user;} public void setUser(User v){user=v;} public String getIssueTitle(){return issueTitle;} public void setIssueTitle(String v){issueTitle=v;} public String getIssueDescription(){return issueDescription;} public void setIssueDescription(String v){issueDescription=v;} public IssueStatus getStatus(){return status;} public void setStatus(IssueStatus v){status=v;} public String getResolutionNotes(){return resolutionNotes;} public void setResolutionNotes(String v){resolutionNotes=v;} public LocalDateTime getCreatedAt(){return createdAt;} public LocalDateTime getUpdatedAt(){return updatedAt;}
}
