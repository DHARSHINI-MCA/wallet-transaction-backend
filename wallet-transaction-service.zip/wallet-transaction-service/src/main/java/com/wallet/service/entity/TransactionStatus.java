package com.wallet.service.entity;

public enum TransactionStatus { SUCCESS, FAILED }
