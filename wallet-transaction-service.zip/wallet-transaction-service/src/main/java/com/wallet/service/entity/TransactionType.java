package com.wallet.service.entity;

public enum TransactionType { CREDIT, DEBIT }
