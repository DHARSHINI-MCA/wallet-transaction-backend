package com.wallet.service.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.LocalDateTime;

@Entity @Table(name="users")
public class User {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(name="first_name", nullable=false, length=100) private String firstName;
 @Column(name="last_name", length=100) private String lastName;
 @Column(nullable=false, unique=true, length=255) private String email;
 @JsonIgnore @Column(nullable=false, length=255) private String password;
 @Enumerated(EnumType.STRING) @Column(nullable=false, length=20) private Role role=Role.CUSTOMER;
 @Enumerated(EnumType.STRING) @Column(nullable=false, length=20) private UserStatus status=UserStatus.ACTIVE;
 @Column(name="last_login_at") private LocalDateTime lastLoginAt;
 @Column(name="created_at", nullable=false) private LocalDateTime createdAt;
 @Column(name="updated_at", nullable=false) private LocalDateTime updatedAt;
 @Column(name="password_reset_required", nullable=false) private boolean passwordResetRequired=true;
 @PrePersist void prePersist(){var n=LocalDateTime.now(); createdAt=n; updatedAt=n;}
 @PreUpdate void preUpdate(){updatedAt=LocalDateTime.now();}
 public Long getId(){return id;} public String getFirstName(){return firstName;} public void setFirstName(String v){firstName=v;} public String getLastName(){return lastName;} public void setLastName(String v){lastName=v;} public String getEmail(){return email;} public void setEmail(String v){email=v;} public String getPassword(){return password;} public void setPassword(String v){password=v;} public Role getRole(){return role;} public void setRole(Role v){role=v;} public UserStatus getStatus(){return status;} public void setStatus(UserStatus v){status=v;} public LocalDateTime getLastLoginAt(){return lastLoginAt;} public void setLastLoginAt(LocalDateTime v){lastLoginAt=v;} public LocalDateTime getCreatedAt(){return createdAt;} public LocalDateTime getUpdatedAt(){return updatedAt;} public boolean isPasswordResetRequired(){return passwordResetRequired;} public void setPasswordResetRequired(boolean v){passwordResetRequired=v;}
}
