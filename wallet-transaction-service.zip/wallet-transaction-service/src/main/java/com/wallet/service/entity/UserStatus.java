package com.wallet.service.entity;

public enum UserStatus { ACTIVE, INACTIVE }
