package com.wallet.service.entity;

public enum WalletStatus { ACTIVE, INACTIVE }
