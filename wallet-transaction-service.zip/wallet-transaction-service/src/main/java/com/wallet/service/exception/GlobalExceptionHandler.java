package com.wallet.service.exception;
import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import org.springframework.web.bind.MethodArgumentNotValidException; import java.util.*;
@RestControllerAdvice public class GlobalExceptionHandler {
 @ExceptionHandler({ResourceNotFoundException.class,BusinessException.class}) ResponseEntity<Map<String,Object>> business(RuntimeException e){return ResponseEntity.badRequest().body(Map.of("error",e.getMessage()));}
 @ExceptionHandler(MethodArgumentNotValidException.class) ResponseEntity<Map<String,Object>> validation(MethodArgumentNotValidException e){var m=new HashMap<String,Object>();m.put("error","Validation failed");m.put("details",e.getBindingResult().getFieldErrors().stream().collect(java.util.stream.Collectors.toMap(x->x.getField(),x->x.getDefaultMessage(),(a,b)->a)));return ResponseEntity.badRequest().body(m);}
 @ExceptionHandler(Exception.class) ResponseEntity<Map<String,Object>> other(Exception e){return ResponseEntity.status(500).body(Map.of("error","Internal server error","details",e.getMessage()));}
}
