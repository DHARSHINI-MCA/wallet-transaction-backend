package com.wallet.service.exception; public class ResourceNotFoundException extends RuntimeException{ public ResourceNotFoundException(String m){super(m);} }
