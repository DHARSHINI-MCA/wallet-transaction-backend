package com.wallet.service.repository;
import com.wallet.service.entity.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface TransactionIssueRepository extends JpaRepository<TransactionIssue,Long>{ List<TransactionIssue> findByUserIdOrderByCreatedAtDesc(Long userId); List<TransactionIssue> findAllByOrderByCreatedAtDesc(); }
