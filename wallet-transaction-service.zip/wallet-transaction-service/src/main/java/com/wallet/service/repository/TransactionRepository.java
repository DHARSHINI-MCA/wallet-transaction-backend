package com.wallet.service.repository;
import com.wallet.service.entity.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface TransactionRepository extends JpaRepository<Transaction,Long>{ List<Transaction> findByWalletIdOrderByTransactionTimeDesc(Long walletId); Optional<Transaction> findByTransactionReference(String ref); long countByStatus(TransactionStatus status); List<Transaction> findByTransactionTypeAndStatus(TransactionType type,TransactionStatus status); }
