package com.wallet.service.repository;
import com.wallet.service.entity.UserLog; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface UserLogRepository extends JpaRepository<UserLog,Long>{ List<UserLog> findByUserIdOrderByCreatedAtDesc(Long userId); List<UserLog> findAllByOrderByCreatedAtDesc(); }
