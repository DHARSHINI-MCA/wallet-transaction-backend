package com.wallet.service.repository;
import com.wallet.service.entity.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.Optional;
public interface UserRepository extends JpaRepository<User,Long>{ Optional<User> findByEmail(String email); boolean existsByEmail(String email); long countByStatus(UserStatus status); }
