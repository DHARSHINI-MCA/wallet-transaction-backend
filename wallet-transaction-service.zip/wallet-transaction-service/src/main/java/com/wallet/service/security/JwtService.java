package com.wallet.service.security;
import io.jsonwebtoken.*; import io.jsonwebtoken.security.Keys; import org.springframework.beans.factory.annotation.Value; import org.springframework.stereotype.Service; import java.nio.charset.StandardCharsets; import java.security.Key; import java.util.Date;
@Service public class JwtService { @Value("${app.jwt.secret}") private String secret; @Value("${app.jwt.expiration-ms}") private long expiration; private Key key(){return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));}
 public String generate(String email,String role){Date now=new Date();return Jwts.builder().subject(email).claim("role",role).issuedAt(now).expiration(new Date(now.getTime()+expiration)).signWith(key()).compact();}
 public String extractEmail(String token){return Jwts.parser().verifyWith((javax.crypto.SecretKey)key()).build().parseSignedClaims(token).getPayload().getSubject();}
 public boolean valid(String token,String email){try{return extractEmail(token).equals(email) && !Jwts.parser().verifyWith((javax.crypto.SecretKey)key()).build().parseSignedClaims(token).getPayload().getExpiration().before(new Date());}catch(Exception e){return false;}} }
