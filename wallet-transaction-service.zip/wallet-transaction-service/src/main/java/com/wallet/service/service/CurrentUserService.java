package com.wallet.service.service;
import com.wallet.service.repository.UserRepository; import org.springframework.security.core.Authentication; import org.springframework.stereotype.Service; import com.wallet.service.entity.User;
@Service public class CurrentUserService { private final UserRepository users; public CurrentUserService(UserRepository u){users=u;} public User get(Authentication a){return users.findByEmail(a.getName()).orElseThrow();} }
