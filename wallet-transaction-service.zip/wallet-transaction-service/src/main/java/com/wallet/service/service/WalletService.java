package com.wallet.service.service;
import com.wallet.service.entity.*; import com.wallet.service.exception.*; import com.wallet.service.repository.*; import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional; import java.util.*;
@Service public class WalletService { private final WalletRepository wallets; public WalletService(WalletRepository w){wallets=w;} public Wallet myWallet(Long userId){return wallets.findByUserId(userId).orElseThrow(()->new ResourceNotFoundException("Wallet not found"));} public List<Wallet> all(){return wallets.findAll();}
 @Transactional public void setStatus(Long id,WalletStatus status){var w=wallets.findById(id).orElseThrow(()->new ResourceNotFoundException("Wallet not found"));w.setStatus(status);wallets.save(w);}
}
