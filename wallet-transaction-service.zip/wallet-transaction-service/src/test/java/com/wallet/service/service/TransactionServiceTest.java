package com.wallet.service.service;

import com.wallet.service.dto.AmountRequest; import com.wallet.service.entity.*; import com.wallet.service.exception.BusinessException; import com.wallet.service.repository.*; import org.junit.jupiter.api.Test; import org.mockito.Mockito; import java.math.BigDecimal; import static org.junit.jupiter.api.Assertions.assertThrows;
class TransactionServiceTest {
 @Test void debitCannotMakeBalanceNegative(){WalletRepository wr=Mockito.mock(WalletRepository.class);TransactionRepository tr=Mockito.mock(TransactionRepository.class);UserLogRepository lr=Mockito.mock(UserLogRepository.class);User u=new User();Wallet w=new Wallet();w.setUser(u);w.setBalance(new BigDecimal("10.00"));w.setStatus(WalletStatus.ACTIVE);Mockito.when(wr.findByUserId(Mockito.anyLong())).thenReturn(java.util.Optional.of(w));TransactionService s=new TransactionService(wr,tr,lr);assertThrows(BusinessException.class,()->s.debit(1L,new AmountRequest(new BigDecimal("20.00"),"test")));}
}
